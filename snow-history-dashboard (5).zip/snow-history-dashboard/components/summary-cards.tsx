"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

type SummaryCard = {
  title: string
  value: number
}

export function SummaryCards() {
  const [summaryCards, setSummaryCards] = useState<SummaryCard[]>([])

  useEffect(() => {
    fetch('/dashboard-data.json')
      .then(response => response.json())
      .then(data => setSummaryCards(data.summaryCards))
  }, [])

  return (
    <div className="grid grid-cols-4 gap-4 mb-4">
      {summaryCards.map((item) => (
        <Card key={item.title}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{item.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{item.value}</div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

