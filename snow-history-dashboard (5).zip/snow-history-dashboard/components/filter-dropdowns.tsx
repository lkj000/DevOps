"use client"

import { useEffect, useState } from "react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const dropdowns = [
  "Portfolio", "Department", "Team", "Manager", "Assigned To", 
  "State", "SLA Status", "Problem", "Change"
]

export function FilterDropdowns() {
  const [filterOptions, setFilterOptions] = useState<Record<string, string[]>>({})

  useEffect(() => {
    fetch('/dashboard-data.json')
      .then(response => response.json())
      .then(data => setFilterOptions(data.filterOptions))
  }, [])

  return (
    <div className="grid grid-cols-3 gap-4 mb-4">
      {dropdowns.map((dropdown) => {
        const options = filterOptions[dropdown.toLowerCase().replace(' ', '') as keyof typeof filterOptions] || []
        return (
          <Select key={dropdown}>
            <SelectTrigger>
              <SelectValue placeholder={dropdown} />
            </SelectTrigger>
            <SelectContent>
              {options.map((option) => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )
      })}
    </div>
  )
}

