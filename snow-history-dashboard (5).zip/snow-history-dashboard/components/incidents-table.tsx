"use client"

import { useEffect, useState } from "react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

type Incident = {
  id: string
  portfolio: string
  department: string
  team: string
  manager: string
  assignedTo: string
  state: string
  slaStatus: string
  problem: string
  change: string
  opened: string
  closed: string
}

export function IncidentsTable() {
  const [incidents, setIncidents] = useState<Incident[]>([])

  useEffect(() => {
    fetch('/dashboard-data.json')
      .then(response => response.json())
      .then(data => setIncidents(data.incidents))
  }, [])

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Incident #</TableHead>
          <TableHead>Portfolio</TableHead>
          <TableHead>Department</TableHead>
          <TableHead>Team</TableHead>
          <TableHead>Manager</TableHead>
          <TableHead>Assigned To</TableHead>
          <TableHead>State</TableHead>
          <TableHead>SLA Status</TableHead>
          <TableHead>Problem</TableHead>
          <TableHead>Change</TableHead>
          <TableHead>Opened (Date)</TableHead>
          <TableHead>Closed (Date)</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {incidents.map((incident) => (
          <TableRow key={incident.id}>
            <TableCell>{incident.id}</TableCell>
            <TableCell>{incident.portfolio}</TableCell>
            <TableCell>{incident.department}</TableCell>
            <TableCell>{incident.team}</TableCell>
            <TableCell>{incident.manager}</TableCell>
            <TableCell>{incident.assignedTo}</TableCell>
            <TableCell>{incident.state}</TableCell>
            <TableCell>{incident.slaStatus}</TableCell>
            <TableCell>{incident.problem}</TableCell>
            <TableCell>{incident.change}</TableCell>
            <TableCell>{incident.opened}</TableCell>
            <TableCell>{incident.closed}</TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}

