import { Card, CardContent } from "@/components/ui/card"

export function Header() {
  return (
    <Card className="mb-4">
      <CardContent className="flex flex-col items-start p-4">
        <div className="text-2xl font-bold">SNOW History User</div>
        <div className="text-sm text-muted-foreground">Service Now Tickets in last 90 days</div>
      </CardContent>
    </Card>
  )
}

