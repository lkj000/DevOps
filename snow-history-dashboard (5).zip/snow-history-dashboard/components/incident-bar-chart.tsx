"use client"

import { useEffect, useState } from "react"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

type IncidentData = {
  month: string
  total: number
}

export function IncidentBarChart() {
  const [incidentData, setIncidentData] = useState<IncidentData[]>([])

  useEffect(() => {
    fetch('/dashboard-data.json')
      .then(response => response.json())
      .then(data => setIncidentData(data.incidentsByMonth))
  }, [])

  return (
    <Card className="mb-4">
      <CardHeader>
        <CardTitle>Total Incidents by Month-Year</CardTitle>
      </CardHeader>
      <CardContent className="pl-2">
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={incidentData}>
            <XAxis
              dataKey="month"
              stroke="#888888"
              fontSize={12}
              tickLine={false}
              axisLine={false}
            />
            <YAxis
              stroke="#888888"
              fontSize={12}
              tickLine={false}
              axisLine={false}
              tickFormatter={(value) => `${value}`}
            />
            <Bar dataKey="total" fill="#adfa1d" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

