import { Header } from "@/components/header"
import { FilterDropdowns } from "@/components/filter-dropdowns"
import { SummaryCards } from "@/components/summary-cards"
import { IncidentBarChart } from "@/components/incident-bar-chart"
import { IncidentsTable } from "@/components/incidents-table"

export default function Dashboard() {
  return (
    <div className="container mx-auto p-4">
      <Header />
      <FilterDropdowns />
      <SummaryCards />
      <IncidentBarChart />
      <IncidentsTable />
    </div>
  )
}

