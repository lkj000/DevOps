import FilterDropdown from './FilterDropdown'
import StatsCard from './StatsCard'
import BarChart from './BarChart'
import DataTable from './DataTable'
import { mockData } from '../mockData'

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <h1 className="text-3xl font-bold mb-8">SNOW History User Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {Object.entries(mockData.filterOptions).map(([key, options]) => (
          <FilterDropdown key={key} label={key.charAt(0).toUpperCase() + key.slice(1)} options={options} />
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {mockData.stats.map((stat, index) => (
          <StatsCard key={index} title={stat.title} value={stat.value} />
        ))}
      </div>

      <div className="bg-gray-800 rounded-lg shadow-lg p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">Incidents by Month</h2>
        <BarChart data={mockData.incidentsByMonth} />
      </div>

      <div className="bg-gray-800 rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Incident Statistics</h2>
        <DataTable data={mockData.tableData} />
      </div>
    </div>
  )
}

