export const mockData = {
  stats: [
    { title: "Total Incidents", value: 1234 },
    { title: "Open Incidents", value: 423 },
    { title: "Closed Incidents", value: 811 },
    { title: "Critical Incidents", value: 56 },
  ],
  incidentsByMonth: [
    { month: "Jan", count: 65 },
    { month: "Feb", count: 59 },
    { month: "Mar", count: 80 },
    { month: "Apr", count: 81 },
    { month: "May", count: 56 },
    { month: "Jun", count: 55 },
    { month: "Jul", count: 40 },
  ],
  tableData: [
    { category: "Network", count: 423, percentage: 34.3 },
    { category: "Hardware", count: 256, percentage: 20.7 },
    { category: "Software", count: 345, percentage: 28 },
    { category: "Security", count: 190, percentage: 15.4 },
    { category: "Other", count: 20, percentage: 1.6 },
  ],
  filterOptions: {
    portfolio: ["IT", "HR", "Finance", "Marketing"],
    department: ["Support", "Development", "Operations", "Security"],
    team: ["Network", "Hardware", "Software", "Security"],
    manager: ["John Doe", "Jane Smith", "Mike Johnson", "Sarah Williams"],
    assignedTo: ["Team A", "Team B", "Team C", "Team D"],
    state: ["Open", "In Progress", "Resolved", "Closed"],
    slaStatus: ["On Track", "At Risk", "Breached", "Completed"],
    problem: ["Critical", "High", "Medium", "Low"],
    change: ["Yes", "No"],
  },
};

